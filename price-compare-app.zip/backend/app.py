from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from scraper import get_price_comparison

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/compare', methods=['GET'])
def compare_prices():
    query = request.args.get('query')
    if not query:
        return jsonify({"error": "Missing query parameter"}), 400
    results = get_price_comparison(query)
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
