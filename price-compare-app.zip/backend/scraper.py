from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import time

def scrape_flipkart_prices(query):
    options = Options()
    options.add_argument('--headless=new')
    options.add_argument('--disable-gpu')
    options.add_argument('--no-sandbox')
    options.add_argument('--log-level=3')
    service = Service()
    driver = webdriver.Chrome(service=service, options=options)

    try:
        url = f"https://www.flipkart.com/search?q={query.replace(' ', '+')}"
        driver.get(url)
        time.sleep(2)

        products = []
        product_elements = driver.find_elements(By.CSS_SELECTOR, 'div._1AtVbE')[:5]

        for elem in product_elements:
            try:
                name = elem.find_element(By.CSS_SELECTOR, 'div._4rR01T').text
                price = elem.find_element(By.CSS_SELECTOR, 'div._30jeq3').text
                link = elem.find_element(By.TAG_NAME, 'a').get_attribute('href')
                products.append({
                    "name": name,
                    "price": price,
                    "link": link
                })
            except:
                continue

        return products if products else [{"error": "No products found"}]
    except Exception as e:
        return [{"error": str(e)}]
    finally:
        driver.quit()

def scrape_amazon_prices(query):
    return [{
        "name": f"Amazon {query} Product 1",
        "price": "₹2,999",
        "link": "https://www.amazon.in/"
    }]

def scrape_reliance_prices(query):
    return [{
        "name": f"Reliance Digital {query} Product 1",
        "price": "₹3,999",
        "link": "https://www.reliancedigital.in/"
    }]

def get_price_comparison(query):
    return {
        "Flipkart": scrape_flipkart_prices(query),
        "Amazon": scrape_amazon_prices(query),
        "Reliance": scrape_reliance_prices(query)
    }
